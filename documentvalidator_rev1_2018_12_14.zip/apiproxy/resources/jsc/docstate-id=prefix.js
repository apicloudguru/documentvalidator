var docId =  context.getVariable("docs.id");
var docStateId = "wonka_" + docId;
context.setVariable("docs.docStateId", docStateId);
